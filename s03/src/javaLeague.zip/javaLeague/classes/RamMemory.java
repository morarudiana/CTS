package javaLeague.classes;


public class RamMemory extends Electronics {
    private int capacity;

    public RamMemory(String manufacturer, int yearManufactured, double price, int capacity) {
        super(manufacturer, yearManufactured, price);
        this.capacity = capacity;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return "RamMemory{" +
                "manufacturer='" + getManufacturer() + '\'' +
                ", yearManufactured=" + getYearManufactured() +
                ", price=" + getPrice() +
                ", capacity=" + capacity +
                '}';
    }
}