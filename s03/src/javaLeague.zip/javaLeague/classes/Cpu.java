package javaLeague.classes;

public class Cpu extends Electronics {
    private String brand;

    public Cpu(String manufacturer, int yearManufactured, double price, String brand) {
        super(manufacturer, yearManufactured, price);
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    @Override
    public String toString() {
        return "Cpu{" +
                "manufacturer='" + getManufacturer() + '\'' +
                ", yearManufactured=" + getYearManufactured() +
                ", price=" + getPrice() +
                ", brand='" + brand + '\'' +
                '}';
    }
}