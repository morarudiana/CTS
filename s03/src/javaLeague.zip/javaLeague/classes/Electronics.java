package javaLeague.classes;
public class Electronics {
    private String manufacturer;
    private int yearManufactured;
    private double price;

    public Electronics(String manufacturer, int yearManufactured, double price) {
        this.manufacturer = manufacturer;
        this.yearManufactured = yearManufactured;
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public int getYearManufactured() {
        return yearManufactured;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Electronics{" +
                "manufacturer='" + manufacturer + '\'' +
                ", yearManufactured=" + yearManufactured +
                ", price=" + price +
                '}';
    }
}
