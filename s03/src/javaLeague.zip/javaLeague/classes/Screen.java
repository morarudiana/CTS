package javaLeague.classes;

public class Screen extends Electronics {
    private double size;
    private String resolution;

    public Screen(String manufacturer, int yearManufactured, double price, double size, String resolution) {
        super(manufacturer, yearManufactured, price);
        this.size = size;
        this.resolution = resolution;
    }

    public double getSize() {
        return size;
    }

    public String getResolution() {
        return resolution;
    }

    @Override
    public String toString() {
        return "Screen{" +
                "manufacturer='" + getManufacturer() + '\'' +
                ", yearManufactured=" + getYearManufactured() +
                ", price=" + getPrice() +
                ", size=" + size +
                ", resolution='" + resolution + '\'' +
                '}';
    }
}
