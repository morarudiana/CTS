package javaLeague.classes;

public class Phone extends Electronics {
    private String model;

    public Phone(String manufacturer, int yearManufactured, double price, String model) {
        super(manufacturer, yearManufactured, price);
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    @Override
    public String toString() {
        return "Phone{" +
                "manufacturer='" + getManufacturer() + '\'' +
                ", yearManufactured=" + getYearManufactured() +
                ", price=" + getPrice() +
                ", model='" + model + '\'' +
                '}';
    }
}
