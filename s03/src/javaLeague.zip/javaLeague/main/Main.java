package javaLeague.main;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javaLeague.classes.Computer;
import javaLeague.classes.Cpu;
import javaLeague.classes.Electronics;
import javaLeague.classes.Phone;
import javaLeague.classes.Screen;

public class Main {
    public static void main(String[] args) {
        List<Electronics> electronicsList = new ArrayList<>();
        electronicsList.add(new Phone("Apple", 2020, 999.99, "iPhone"));
        electronicsList.add(new Phone("Samsung", 2021, 899.99, "Galaxy"));
        electronicsList.add(new Cpu("Intel", 2019, 499.99, "Core i7"));
        electronicsList.add(new Cpu("AMD", 2020, 399.99, "Ryzen 9"));
        electronicsList.add(new Computer("Dell", 2018, 1499.99, "DellLaptop"));
        electronicsList.add(new Screen("LG", 2022, 699.99, 27, "LGScreen"));
        
        String manufacturer = "Apple";
        int year = 2020;
        List<Electronics> filteredList = electronicsList.stream()
                .filter(e -> e.getManufacturer().equals(manufacturer) && e.getYearManufactured() > year)
                .collect(Collectors.toList());

        System.out.printf("Electronics from %s manufactured after %d:\n", manufacturer, year);
        filteredList.forEach(System.out::println);
    
        List<Computer> laptopList = new ArrayList<>();
        laptopList.add(new Computer("Dell", 2021, 1199.99, "DellLaptop"));
        laptopList.add(new Computer("Lenovo", 2020, 999.99, "LenovoLaptop"));
        laptopList.add(new Computer("Asus", 2022, 899.99, "ASUS TUF GAMING"));
        laptopList.add(new Computer("HP", 2021, 799.99, "HPLaptop"));
        List<Computer> filteredListNew = laptopList.stream()
                .filter(l -> l.getModel().equals("FULLHD") && l.getModel().equals("Intel"))
                .collect(Collectors.toList());

        System.out.println("Laptops with FULLHD display and INTEL cpu:");
        filteredList.forEach(System.out::println);
    }
}
